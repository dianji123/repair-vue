// pages/order/order.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
      id: 0,
      image_hostUrl: "http://localhost/image/",
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function(options) {
    this.getOrderItem(options.id)
    //console.log("opid:"+options.id)
  },

  // 获取报修订单详情信息
  getOrderItem: function(id){
    var that = this
    this.setData({
      loadingHidden: false
    })
    wx.showNavigationBarLoading()

    //console.log('id', this.data.id)
    wx.request({
      url: 'http://localhost/api/getOrder.php',
      method: "POST",
      data: {
        id: id,
      },
      header: {
        "content-type": "application/json",
      },
      success: function(e){
        that.setData({
          loadingHidden: true          
        })
        wx.hideNavigationBarLoading()  // 停止加载动画
        //console.log(e.statusCode)

        if(e.data != null){
          //console.log("e:data:"+e.data.orders[0].id)
          that.setData({
            Order: e.data.orders[0]
          })

          that.setData({
            id: e.data.orders[0].id
          })
        }
      },
      fail: function(e){
        console.log(e.statusCode)
      },
    })
  },
  navigateBack: function() {
    wx.navigateBack({
      delta: 1 // 返回上一页
    });
  },
})