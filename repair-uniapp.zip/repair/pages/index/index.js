// index.js
const app = getApp()
Page({
  data:{
    hasLogin: false,
    apiuser_id: 0,
    isUpload: false,
    imageFile: "", //图片的本地临时地址
    serverImageFile: "", //上传到服务器后的文件名
  },

  onShow: function() {
    //页面出现在前台时执行
    var that = this
    try {
      //页面创建时执行，从本地缓存中读取'hasLogin'这个key所指定的值
      var has_login_value = wx.getStorageSync('HAS_LOGIN')
      var apiuser_id_value = wx.getStorageSync('APIUSER_ID')
      //console.log("apiuser_id_value:"+ apiuser_id_value)
      if (has_login_value) {
        //如果已登录，则设置当前页面的hasLogin字段
        that.setData({
          hasLogin: has_login_value,
        })
        that.setData({
          apiuser_id: apiuser_id_value,
        })
      }
    } catch(e){
    }
  },
  
  uploadImage(){
    var that = this
    wx.chooseImage({
      //从本地相册选择图片或相机拍照
      count: 1,
      success (res) {
        //tempFilePaths可以作为img标签的src属性图片
        const tempFilePaths = res.tempFilePaths

        wx.showLoading({
          title: '上传中...',
        })
        wx.uploadFile({
          filePath: tempFilePaths[0],
          name: 'image_file',
          url: 'http://localhost/api/uploadFile.php',
          success:function(uploadres){
            //console.log('上传成功',  uploadres)
            wx.hideLoading()
            wx.showToast({
              title: '图片上传成功',
            })
            //console.log(uploadres.data)
            var resObj = JSON.parse(uploadres.data)
            that.data.serverImageFile = resObj.imageName
            // console.log(that.data.serverImageFile)

            that.setData({
              imageFile: tempFilePaths[0],
            })
            that.setData({
              isUpload: true,
            })
          }
        })
      }
    })
  },

  formSubmit(e){
    //console.log('form发生了submit时间，携带数据为：',e.detail.value)
    var formData = e.detail.value

    if (!this.data.hasLogin) {
      wx.showModal({
        title: '未登录',
        content: '请您先登录',
        success (res) {
          if (res.confirm) {
            //console.log('用户点击确定')

            wx.switchTab({
              url: '/pages/user/user',
            })

          } else if (res.cancel) {
            console.log('用户点击取消')
          }
        }
      })

      return;
    }

    wx.request({
      url: 'http://localhost/api/insertOrder.php',
      method: 'POST',
      data: {
        user_name: formData['user_name'],
        telphone: formData['telphone'],
        area: formData['area'],
        room: formData['room'],
        information: formData['information'],
        apiuser_id: this.data.apiuser_id,
        image_file: this.data.serverImageFile,
      },//设置请求参数
      header: {
        "content-type": "application/json",
      },
      success: function (e) {
        //服务器返回的HTTP状态码
        //console.log("response_code:"+e.statusCode)

        //接口的返回数据
        //console.log("e.data:" + e.data.msg)
        //console.log("e.data:" + e.data['code'])
        //如果code为1 数据插入成功 提示成功信息
        if(e.data.code == 1){
          wx.showToast({
            title: '已提交',
            icon: 'success',
            duration: 2000,
            success: function () {
              setTimeout(function () {
              }, 2000)
            }
          })
        }
      },
      fail: function (e) {
        console.log("fail:"+e.statusCode)
      },
    })
  }
})