const app = getApp()
Page({
  data: {
    hasLogin: false,
    apiuser_id: 0,
    image_hostUrl: "http://localhost/image/",
    //orderList: [], //存放订单数据
  },

  onLoad() {
    var that = this
    try {
      //每次重新登录
      // wx.setStorageSync('HAS_LOGIN', false)
      //从本地缓存中读取'hasLogin'这个key所指定的值
      var value = wx.getStorageSync('HAS_LOGIN')
      //console.log("Storage hasLogin:"+ value)

      var apiuser_id_value = wx.getStorageSync('APIUSER_ID');

      if(value) {
        //如果已登录，则设置当前页面的hasLogin字段
        that.setData({
          hasLogin: value,
        })
        that.setData({
          apiuser_id: apiuser_id_value,
        })
        
      }
    } catch(e){

    }
  },

  onShow: function(){
    var that = this
    that.getOrderList(that)
    var showOrder = wx.getStorageSync('HAS_LOGIN')
    if(showOrder == 'true'){
      that.getOrderList(that)
    }
  },

  getOrderList: function(that){
    that.setData({
      loadingHidden: false
    })
    wx.showNavigationBarLoading()  //加载动画 
    //console.log('apiuser_id:', that.data.apiuser_id)
    wx.request({
      url: 'http://localhost/api/listOrder.php',
      method: 'POST',
      data: {
        apiuser_id: that.data.apiuser_id,
      },
      header: { 
        "content-type": "application/json",
      },
      success: function(e){
        that.setData({
          loadingHidden: true          
        })
        wx.hideNavigationBarLoading()  // 停止加载动画
        //console.log(e.statusCode)

        if(e.data != null){
          that.setData({
            orderList: e.data.orders
          })
        }
      },
      fail: function(e){
        console.log(e.statusCode)
      },
    })
  },

  login() {
    const that = this
    //调用接口获取登录凭证(code)
    wx.login({
      success: function (res) {
        //console.log("rescode:"+res.code)
        if(res.code){
          //调用后端接口，code作为参数
          wx.request({
            url: 'http://localhost/api/login.php',
            method: 'POST',
            data: {
              code: res.code
            },
            success: function (res) {
              //console.log("res_statuscode:"+res.statusCode)
              //登录成功
              if(res.statusCode === 200){
                //console.log(res.data)

                //登录信息存入本地存储
                wx.setStorageSync('APIUSER_ID', res.data.apiuser_id)

                //设置登录状态
                app.globalData.hasLogin = true
                //console.log("appglo:"+app.globalData.hasLogin)
                //登录状态存入本地存储
                wx.setStorageSync('HAS_LOGIN', true)

                that.setData({
                  hasLogin: true
                })

                that.setData({
                  apiuser_id: res.data.apiuser_id
                })

                //查询报修订单
                that.getOrderList(that)
              }
            }
          })
        } else{
          console.log('获取用户登录状态失败！'+ res.errMsg)
        }
      }
    })
  }
})