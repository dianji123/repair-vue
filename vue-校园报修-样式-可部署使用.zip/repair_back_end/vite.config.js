import { fileURLToPath, URL } from 'node:url'

import { defineConfig } from 'vite'
import vue from '@vitejs/plugin-vue'

// https://vitejs.dev/config/
export default defineConfig({
  plugins: [
    vue(),
  ],
  resolve: {
    alias: {
      '@': fileURLToPath(new URL('./src', import.meta.url))
    }
  },
  server: {
    // 服务器主机名，默认是 localhost
    host: 'localhost',
    port: 10003,
    proxy: {
      '/api': {
        target: 'http://8.130.99.29:10004',
        changeOrigin: true,
        rewrite: (path) => path.replace(/^\/api/, ''),
        open: true
      }
    },
  },
})
