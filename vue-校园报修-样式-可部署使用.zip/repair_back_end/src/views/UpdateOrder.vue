<template>
  <div class="content-container">
    <el-button size="small" @click="goBack">返回</el-button> <!-- 返回按钮 -->
    <h2>编辑报修订单</h2>
    <form v-if="order" @submit.prevent="updateStatus">
      <div v-if="order">
        <p><strong>姓名：</strong> {{ order.user_name }}</p>
        <p><strong>电话号码：</strong> {{ order.telphone }}</p>
        <p><strong>楼栋：</strong> {{ order.area }}</p>
        <p><strong>房号：</strong> {{ order.room }}</p>
        <p><strong>故障详情：</strong> {{ order.information }}</p>
        <p><strong>图片：</strong> 
          <img v-if="order && order.image_file" :src="getImageUrl(order.image_file)" alt="图片" style="max-width: 100px; max-height: 100px;">
        </p>
        <p><strong>报修状态：</strong> {{ order.status }}</p>
        <div>
          <label for="status">报修状态：</label>
          <el-select id="status" v-model="status" placeholder="请选择">
            <el-option value="待处理" label="待处理"></el-option>
            <el-option value="已完成" label="已完成"></el-option>
          </el-select>
        </div>
        <el-button type="primary" native-type="submit">提交</el-button>
      </div>
    </form>
  </div>
</template>

<script>
import axios from '../request/axios.config.js';
import { ref, onMounted } from 'vue';
import { useRouter, useRoute } from 'vue-router';
import { ElButton, ElSelect, ElOption } from 'element-plus';

export default {
  name: 'UpdateOrder',
  components: {
    ElButton,
    ElSelect,
    ElOption
  },
  setup() {
    const order = ref({});
    const status = ref('');
    const router = useRouter();
    const route = useRoute();

    const updateStatus = () => {
      const orderId = route.query.id;
      axios
        .post('/api/admin/_updateOrder.php', {
          id: orderId,
          status: status.value,
        })
        .then(() => {
          router.push({ name: 'ListOrder' });
        })
        .catch((error) => {
          console.error('报修状态更新失败:', error);
        });
    };

    const fetchOrderData = () => {
      const orderId = route.query.id;
      axios
        .get(`/api/admin/_getOrder.php?id=${orderId}`)
        .then((res) => {
          order.value = res.data[0];
          status.value = order.value.status;
        })
        .catch((error) => {
          console.error('获取订单信息失败:', error);
        });
    };

    onMounted(() => {
      fetchOrderData(); // 获取订单信息
    });

    const getImageUrl = (image_file) => {
      const apiBaseURL = import.meta.env.VITE_API_BASE_URL;
      // 获取图片路径
      return `${apiBaseURL}/image/` + image_file;
    };

    const goBack = () => {
      router.back(); // 后退到上一个页面
    };

    return {
      order,
      status,
      updateStatus,
      getImageUrl,
      goBack,
    };
  },
};
</script>


<style scoped>
.content-container {
  max-width: 600px;
  margin: 20px auto;
  padding: 20px;
  border: 1px solid #ebeef5;
  border-radius: 4px;
  background-color: #fff;
}

.content-container h2 {
  margin-bottom: 20px;
}

.content-container form {
  display: flex;
  flex-direction: column;
  gap: 15px;
}

.content-container button {
  margin-top: 20px;
  padding: 10px 20px;
  background-color: #409eff;
  color: white;
  border: none;
  cursor: pointer;
  border-radius: 4px;
}

.content-container button:hover {
  background-color: #66b1ff;
}

.content-container img {
  max-width: 100px;
  max-height: 100px;
  object-fit: contain;
  border: 1px solid #ebeef5;
  border-radius: 4px;
}
</style>