<template>
  <div class="repair-man-list">
    <h2>维修师傅列表</h2>
    <div class="add-button">
      <el-button type="primary" @click="addRepairMan">新增</el-button>
    </div>
    <el-table v-if="tableData.length > 0" :data="tableData" highlight-current-row border stripe style="width: 100%">
      <el-table-column prop="aid" label="序号" width="220" align="center"></el-table-column>
      <el-table-column prop="username" label="用户名" width="220" align="center"></el-table-column>
      <el-table-column prop="realname" label="姓名" width="220" align="center"></el-table-column>
      <el-table-column prop="phone_num" label="手机号" width="250" align="center"></el-table-column>
      <el-table-column label="操作" align="center">
        <template #default="{ row }">
          <el-button size="small" @click="handleEdit(row)">编辑</el-button>
          <el-button size="small" type="danger" @click="handleDelete(row)">删除</el-button>
        </template>
      </el-table-column>
    </el-table>
    <el-alert v-else title="加载中..." type="info" center></el-alert>
  </div>
</template>

<script>
import { ref, onMounted } from 'vue';
import { ElMessage, ElMessageBox } from 'element-plus';
import axios from '../request/axios.config.js';
import { useRouter } from 'vue-router';

export default {
  name: 'RepairManList',
  setup() {
    const tableData = ref([]); // 初始化表格数据
    const router = useRouter(); // 获取路由实例

    const queryRepairManList = () => {
      const token = sessionStorage.getItem('token');
      if (token != null) {
        axios.defaults.headers.common['Authorization'] = 'Bearer ' + token;
        axios.get('/api/admin/_listRepairMan.php')
          .then((res) => {
            tableData.value = res.data;
          })
          .catch((error) => {
            console.error('请求维修师傅列表失败:', error);
          });
      } else {
        console.log("令牌不能为空");
        router.push({ name: 'Login' });
      }
    };

    const addRepairMan = () => {
      router.push({ name: 'AddRepairMan' });
    };

    const handleEdit = (row) => {
      router.push({
        name: 'UpdateRepairMan',
        query: { aid: row.aid }
      });
    };

    const handleDelete = (row) => {
      ElMessageBox.confirm('您确定要删除此维修师傅吗?', '删除维修师傅', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning'
      }).then(() => {
        axios.post('/api/admin/_deleteRepairMan.php', {
          aid: row.aid,
        }).then(() => {
          queryRepairManList();
          ElMessage({
            type: 'success',
            message: '删除成功'
          });
        }).catch((error) => {
          console.error('删除失败:', error);
        });
      }).catch(() => {
        ElMessage({
          type: 'info',
          message: '取消操作'
        });
      });
    };

    onMounted(() => {
      queryRepairManList();
    });

    return { tableData, handleEdit, handleDelete, addRepairMan };
  },
};
</script>

<style scoped>
.repair-man-list {
  padding: 20px;
}

.repair-man-list h2 {
  text-align: center;
  margin-bottom: 20px;
}

.add-button {
  display: flex;
  justify-content: center;
  margin-bottom: 20px;
}

.el-button {
  margin: 0 5px;
}

.el-table {
  margin: 20px auto;
}

.el-alert {
  display: flex;
  justify-content: center;
  margin: 20px;
}
</style>