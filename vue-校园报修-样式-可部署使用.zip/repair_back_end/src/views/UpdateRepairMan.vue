<template>
  <div class="edit-repair-man">
    <el-button size="small" @click="goBack" style="margin-bottom: 20px;">返回</el-button>
    <h2>编辑维修师傅信息</h2>
    
    <form v-if="repairMan" @submit.prevent="updateRepairMan">
      <div>
        <label for="username">用户名：</label>
        <input id="username" type="text" placeholder="请输入用户名" v-model="username" required>
      </div>
      <div>
        <label for="realname">姓名：</label>
        <input id="realname" type="text" placeholder="请输入姓名" v-model="realname" required>
      </div>
      <div>
        <label for="phone_num">手机号：</label>
        <input id="phone_num" type="tel" placeholder="请输入手机号" v-model="phone_num" required pattern="[0-9]{11}">
      </div>

      <button type="submit">提交</button>
    </form>
  </div>
</template>
  
<script>
import axios from '../request/axios.config.js';
import { ref, onMounted } from 'vue';
import { useRouter, useRoute } from 'vue-router';
import { ElButton } from 'element-plus';

export default {
  name: 'UpdateRepairMan',
  components: {
    ElButton
  },
  setup() {
    const repairMan = ref(null);
    const username = ref('');
    const realname = ref('');
    const phone_num = ref('');
    const router = useRouter();
    const route = useRoute();

    const updateRepairMan = async () => {
      const repairManId = route.query.aid;
      try {
        await axios.post('/api/admin/_updateRepairMan.php', {
          aid: repairManId,
          username: username.value,
          realname: realname.value,
          phone_num: phone_num.value,
        });
        router.push({ name: 'RepairMan' });
      } catch (error) {
        console.error('更新失败:', error);
      }
    };

    const fetchRepairManData = async () => {
      const repairManId = route.query.aid;
      try {
        const { data } = await axios.get(`/api/admin/_getRepairMan.php?aid=${repairManId}`);
        repairMan.value = data[0];
        username.value = data[0].username;
        realname.value = data[0].realname;
        phone_num.value = data[0].phone_num;
      } catch (error) {
        console.error('获取信息失败:', error);
      }
    };

    const goBack = () => {
      router.back();
    };

    onMounted(() => {
      fetchRepairManData();
    });

    return {
      repairMan,
      updateRepairMan,
      username,
      realname,
      phone_num,
      goBack,
    };
  },
};
</script>

<style scoped>
.edit-repair-man {
  max-width: 400px;
  margin: 20px auto;
  padding: 20px;
  border: 1px solid #ebeef5;
  border-radius: 4px;
  background-color: #fff;
}

h2 {
  text-align: center;
  margin-bottom: 20px;
}

form {
  display: flex;
  flex-direction: column;
  gap: 15px;
}

label {
  margin-bottom: 5px;
  font-weight: bold;
}

input {
  padding: 10px;
  border-radius: 4px;
  border: 1px solid #dcdfe6;
  font-size: 14px;
}

button {
  padding: 10px 20px;
  margin-top: 10px;
  background-color: #409eff;
  color: white;
  border: none;
  cursor: pointer;
  border-radius: 4px;
  font-size: 14px;
  transition: background-color 0.3s;
}

button:hover {
  background-color: #66b1ff;
}

@media (max-width: 500px) {
  .edit-repair-man {
    width: 90%;
  }
}
</style>
