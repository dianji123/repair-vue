// axios.config.js 或 api.js
import axios from 'axios';

// 环境变量，用于区分开发环境和生产环境的API URL
const API_BASE_URL = import.meta.env.VITE_API_BASE_URL || 'http://localhost:80';

// 创建Axios实例
const instance = axios.create({
  baseURL: API_BASE_URL,
  timeout: 1000, // 请求超时时间
});

// 请求拦截器
instance.interceptors.request.use(config => {
  // 在发送请求之前做些什么
  return config;
}, error => {
  // 处理请求错误
  return Promise.reject(error);
});

// 响应拦截器
instance.interceptors.response.use(response => {
  // 对响应数据做点什么
  return response;
}, error => {
  // 处理响应错误
  return Promise.reject(error);
});

// 导出Axios实例
export default instance;