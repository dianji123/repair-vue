<template>
  <nav class="navbar">
      <router-link to="/">首页</router-link>
      <router-link to="/ListOrder">订单列表</router-link>
      <router-link to="/RepairMan">维修师傅</router-link>
      <router-link to="/" @click="clearToken">退出</router-link>
    </nav>
    <router-view />
    
</template>

<script>
import Login from './views/Login.vue';
import { onMounted, ref } from 'vue';

export default {
  name: 'App',
  components: { Login },
  setup() {

    const clearToken = () => {
      // 移除sessionStorage中的token
      sessionStorage.removeItem('token');
    }

    const backgroundImageUrl = ref(''); // 创建一个响应式引用来存储背景图片URL
    onMounted(() => {
      // 在组件挂载后，设置背景图片URL
      const apiBaseURL = import.meta.env.VITE_API_BASE_URL;
      backgroundImageUrl.value = `${apiBaseURL}/image/bg.jpg`; // 构建完整的URL
      document.body.style.backgroundImage = `url('${backgroundImageUrl.value}')`; // 设置背景图片
    });

    return { clearToken };
  }
};
</script>

  <style>
  /* Global styles */
.container {
  display: flex;
  flex-direction: column; /* 子元素按列排列 */
  justify-content: center; /* 水平居中（在主轴方向） */
  align-items: center; /* 垂直居中 */
  height: 100%;
}
  body {
    font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
    background: url('/api/image/bg.jpg') no-repeat center center fixed;
    background-size: cover;
    background-blend-mode: overlay;
    background-color: rgba(255, 255, 255, 0.5); /* White background with transparency */
  }

  a {
    color: #409eff;
    text-decoration: none;
  }

  a:hover {
    color: #66b1ff;
  }

  .navbar {
  display: flex;
  justify-content: center;
  align-items: center;
  background-color: #333; /* 深色背景 */
  color: white; /* 白色字体 */
  padding: 10px 0; /* 添加一些垂直内边距 */
}

.navbar a {
  color: white; /* 链接文字为白色 */
  margin: 0 15px; /* 在链接之间添加一些水平间距 */
  text-decoration: none; /* 去除下划线 */
  padding: 10px 15px; /* 添加一些内边距 */
  border-radius: 5px; /* 轻微圆角边缘 */
  transition: background-color 0.3s ease; /* 平滑的背景颜色转换效果 */
}

.navbar a:hover {
  background-color: #555; /* 鼠标悬停时背景颜色变暗 */
}

.navbar a.active {
  background-color: #409eff; /* 活动链接的背景颜色 */
  color: white;
}

  .input, select, button {
    padding: 10px;
    border-radius: 4px;
    border: 1px solid #dcdfe6;
    outline: none;
  }

  button {
    background-color: #409eff;
    color: white;
    cursor: pointer;
    border: none;
  }

  button:hover {
    background-color: #66b1ff;
  }


  </style>